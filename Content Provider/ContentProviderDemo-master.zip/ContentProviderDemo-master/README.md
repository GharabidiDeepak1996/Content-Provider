# Content Provider Demo

> A basic sample which shows how to use content provider in Android to share data between two apps.

- AppOne used to add data.
- AppTwo reads the data using shared content provider.
- Implemented [Swipe Refresh Layout](https://developer.android.com/training/swipe/add-swipe-interface.html).

### Author

- Gokul Nath KP
